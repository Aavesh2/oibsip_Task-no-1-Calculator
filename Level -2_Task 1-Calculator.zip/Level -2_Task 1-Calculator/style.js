let inputDisplay = document.getElementById('inputDisplay');
        let resultDisplay = document.getElementById('resultDisplay');

        function append(value) {
            if (inputDisplay.textContent === '0') {
                inputDisplay.textContent = value;
            } else {
                inputDisplay.textContent += value;
            }
        }

        function clearDisplay() {
            inputDisplay.textContent = '0';
            resultDisplay.textContent = '0';
        }

        function deleteLast() {
            inputDisplay.textContent = inputDisplay.textContent.slice(0, -1) || '0';
        }

        function toggleSign() {
            let currentValue = inputDisplay.textContent;
            if (currentValue === '0') return;
            if (currentValue[0] === '-') {
                inputDisplay.textContent = currentValue.slice(1);
            } else {
                inputDisplay.textContent = '-' + currentValue;
            }
        }

        function calculate() {
            try {
                resultDisplay.textContent = eval(inputDisplay.textContent);
            } catch (e) {
                resultDisplay.textContent = 'Error';
            }
        }